<template>
  <div class="module">
    <boost-card
        v-for="item in count"
        :key="item"
        @increase-by="increaseCount"
        @decrease-by="decreaseCount"
    />
  </div>
</template>
<script>

import boostCard from "@/components/Boost/boostCard";
import "./style.scss"
export default {
  name: 'App',
  data() {
    return {
      count: 2,
    }
  },
  components: {
    boostCard,
  },
  methods: {
    increaseCount(n) {
      this.count += n
    },
    decreaseCount(n) {
      if(this.count >1){
        this.count -= n;
      }else {
        alert("It's the last Boost.")
      }
    },
  },
}
</script>
