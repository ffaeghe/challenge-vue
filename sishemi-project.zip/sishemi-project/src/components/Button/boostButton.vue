<template>
  <button :style="btnStyles" class="btn">
    {{ msg }}
  </button>
</template>

<script>
import "./style.scss";
export default {
  name: "boostButton",
  props: {
    msg: String,
    bgColor: {
      type: String,
      default: "#fff",
    },
    color: {
      type: String,
      default: "#ccc",
    },
    border: {
      type: String,
      default: "1px solid #eee",
    },
  },
  computed: {
    btnStyles() {
      return {
        "background-color": this.bgColor,
        "border": this.border,
        "color": this.color,
      };
    }
  },
}
</script>
