<template>
  <div v-if="!show">
    <div class="mainHeader" @click="$emit('increaseBy', 1)">+</div>
    <div class="btcard">
      <boost-button
          :msg="btn"
          :bg-color="btnBg"
          :color ="btnColor"
          :border="btnBorder"
          v-on:click="handleClick"
      />
      <div class="info">
        <span class="title">Date Period</span>
        <span>Pick Date Range:</span>
        <p class="date">
          <span class="cal">2020/09/10</span>
          <span class="to">&nbsp;&nbsp;To&nbsp;&nbsp;</span>
          <span class="cal">2020/09/10</span>
        </p>
      </div>
    </div>
  </div>
  <Transition name="bounce" v-else>
    <div class="body">
      <div class="header" @click="$emit('decreaseBy', 1)"/>
      <div class="card">
        <boost-button
            :msg="boost"
            v-on:click="handleClick"
        />
        <div class="data">
          <p class="link">linking</p>
          <p class="valLik">100</p>
        </div>
      </div>
    </div>
  </Transition>
</template>

<script>
import boostButton from "@/components/Button/boostButton";
import "./style.scss";
export default {
  name: "boostCard",
  data(){
    return{
      boost: 'Boost',
      show: true,
      btn: "CREATE BOOST",
      btnBg: "#eaebfa",
      btnColor: "#6675f9",
      btnBorder: "1px solid #eaebfa",
    };
  },
  components: {
    boostButton,
  },
  methods: {
    handleClick() {
      this.show = !this.show;
    },
  }
}
</script>
